Tool for FUN

UnderDAV:

Help with upload of files in WEBDAV [IIS]

Hot to use:

chmod +x underdav.sh

./underdav.sh


Creted by Jonatas Fil
